package com.example.foodx.models

data class CategoriesResponse(
    val meals: List<CategoryMeals>
)