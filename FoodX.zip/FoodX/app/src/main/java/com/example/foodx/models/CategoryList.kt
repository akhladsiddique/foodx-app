package com.example.foodx.models

data class CategoryList(
    val categories: List<Category>
)