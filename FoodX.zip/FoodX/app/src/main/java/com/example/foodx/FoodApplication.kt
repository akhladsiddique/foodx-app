package com.example.foodx

import android.app.Application

class FoodApplication : Application()