package com.example.foodx.models

data class CuisineList(
    val meals: List<Cuisine>
)