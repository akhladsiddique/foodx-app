package com.example.foodx.models

data class MealResponse(
    val meals: List<Meal>
)